"""
Backward-compatability shims to support Python 3.9 and earlier.
"""

# Debian-specific: Drop compatibility with python 3.9 or earlier
# Do not use jaraco.test, not packaged

#from jaraco.test.cpython import from_test_support, try_import

#import_helper = try_import('import_helper') or from_test_support(
#    'modules_setup', 'modules_cleanup', 'DirsOnSysPath'
#)
#os_helper = try_import('os_helper') or from_test_support('temp_dir')
#warnings_helper = try_import('warnings_helper') or from_test_support(
#    'ignore_warnings', 'check_warnings'
#)

# Debian-specific: Use Python standard library
from test.support import os_helper
from test.support import import_helper
from test.support import warnings_helper
